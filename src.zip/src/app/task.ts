export class Task {
    key:any;
    id:string;
    taskname:string;
    assignedto:string;
    assigneddate:string;
    priority: string;
    status : string;
    active = true;
}
