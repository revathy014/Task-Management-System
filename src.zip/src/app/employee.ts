export class Employee {
    key:any;
    id:string;
    firstname:string;
    lastname:string;
    dob:string;
    gender:string;
    contactnumber :number;
    emailid: string;
    username:string;
    password:string;
    address:string;
    active = true;
}
