// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCiM2wpExZXz_PIM5AIRei12-vUYH9145s",
    authDomain: "loginauthentication-fbdb4.firebaseapp.com",
    projectId: "loginauthentication-fbdb4",
    storageBucket: "loginauthentication-fbdb4.appspot.com",
    messagingSenderId: "383938613890",
    appId: "1:383938613890:web:b34caa300f5122d6d8da9b"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
